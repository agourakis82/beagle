#!/usr/bin/env bash
# sprint230_dbl_comp_xor_gate.sh — Sprint 230: Block EN Double-complement XOR
#
# Block EN: ~x^~y → x^y.
#   Zero new arrays: uses is_bnot/bnot_src (Block BJ/AI).
#   SOTA: GF(2): (x^1)^(y^1) = x^y^0 = x^y.
set -eo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.."; pwd)"; cd "$ROOT_DIR"
PASS=0; FAIL=0; NOT_RUN=0; TOTAL=0
SOUC="./bin/souc"
cg() { local n="$1" p="$2" f="$3"; TOTAL=$((TOTAL+1)); if [ ! -f "$f" ]; then echo "NOT_RUN  $n"; NOT_RUN=$((NOT_RUN+1)); return; fi; if grep -qE "$p" "$f" 2>/dev/null; then echo "PASS  $n"; PASS=$((PASS+1)); else echo "FAIL  $n"; FAIL=$((FAIL+1)); fi; }
cl() { local n="$1" e="$2" l="$3"; TOTAL=$((TOTAL+1)); if [ ! -s "$l" ]; then echo "NOT_RUN  $n (OOM)"; NOT_RUN=$((NOT_RUN+1)); return; fi; if grep -qF "$e" "$l"; then echo "PASS  $n"; PASS=$((PASS+1)); elif ! grep -qF "T1046" "$l" 2>/dev/null; then echo "NOT_RUN  $n (OOM before T1046)"; NOT_RUN=$((NOT_RUN+1)); else echo "FAIL  $n"; FAIL=$((FAIL+1)); fi; }
echo "=== Sprint 230: Block EN — Double-complement XOR ==="
echo ""; echo "--- Source ---"
O="self-hosted/ir/opt_cleanup.sio"
cg "src:block_en"    "Block EN" "$O"
cg "src:en_is_bnot"  "is_bnot\[en_s[12] as usize\]" "$O"
cg "src:en_xor"      "en_instr\.bin_op == BinaryOp::OpBitXor" "$O"
cg "src:en_rewrite"  "ir_binop.*en_instr\.dst.*en_x.*OpBitXor.*en_y" "$O"
echo ""; echo "--- Tests ---"
M="self-hosted/compiler/main.sio"
cg "main:T1046_fn" "fn compiler_main_test_en_dbl_comp_xor_basic" "$M"
cg "main:T1047_fn" "fn compiler_main_test_en_dbl_comp_xor_same" "$M"
cg "main:T1048_fn" "fn compiler_main_test_en_dbl_comp_xor_chain" "$M"
cg "main:T1049_fn" "fn compiler_main_test_en_no_fold_one_not" "$M"
cg "main:T1050_fn" "fn compiler_main_test_en_no_fold_and_op" "$M"
cg "main:T1051_fn" "fn compiler_main_test_en_no_fold_neg_op" "$M"
cg "main:total"    "let total: i64 = [0-9]+" "$M"
echo ""; echo "--- Self-tests: T1046-T1051 ---"
L="$(mktemp)"
if [ ! -x "$SOUC" ]; then for t in T1046 T1047 T1048 T1049 T1050 T1051; do TOTAL=$((TOTAL+1)); echo "NOT_RUN  selftest:$t"; NOT_RUN=$((NOT_RUN+1)); done
else timeout 180 "$SOUC" run self-hosted/compiler/main.sio -- --self-test > "$L" 2>&1 || _ec=$?
for t in T1046 T1047 T1048 T1049 T1050 T1051; do cl "selftest:$t" "$t OK" "$L"; done; fi
rm -f "$L"
echo ""; echo "--- Type-check ---"; TOTAL=$((TOTAL+1))
TC_OUT="$(mktemp)"; if timeout 90 "$SOUC" check self-hosted/compiler/main.sio > "$TC_OUT" 2>&1 && grep -q "All checks passed" "$TC_OUT"; then echo "PASS  typecheck"; PASS=$((PASS+1)); else echo "FAIL  typecheck"; FAIL=$((FAIL+1)); fi; rm -f "$TC_OUT"
echo ""; echo "=== SUMMARY ==="; echo "PASS=$PASS  FAIL=$FAIL  NOT_RUN=$NOT_RUN  TOTAL=$TOTAL"
if [ "$FAIL" -eq 0 ]; then echo "GATE: PASS"; exit 0; else echo "GATE: FAIL"; exit 1; fi
